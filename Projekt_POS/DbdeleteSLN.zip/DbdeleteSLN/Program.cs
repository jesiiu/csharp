﻿using FluentFTP;

Ftp ftp = new Ftp();
try
{
    var status = ftp.UploadFile(@"..\..\..\Database\pos.db");
    Console.WriteLine("Wysłano bazę na serwer FTP");
    if (status == FtpStatus.Success)
    {
        File.Delete(@"..\..\..\Database\pos.db");
        Console.WriteLine("Baza lokalna została spacyfikowana");
    }
}
catch (Exception ex)
{
    Console.WriteLine(ex.Message);
    Console.ReadLine();
}

