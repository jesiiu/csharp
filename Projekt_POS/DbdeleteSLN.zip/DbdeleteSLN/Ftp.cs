﻿using FluentFTP;
using System.Net;
using System.Text;

internal class Ftp
{
    public string _serverAddress = "lockdownband.pl";
    public string _user = "konto_studia@lockdownband.pl";
    public string _password = "GW7PJZY8cS)V";
    private FtpClient _client;

    public string PhotoAddressInfo { get; set; }
    public Ftp()
    {
        // Połączenie z serwerem FTP Mastersport'u
        if (_client == null)
        {
            _client = new FtpClient
            {
                Host = _serverAddress,
                Credentials = new NetworkCredential(_user, _password)
            };
        }
        // Pobranie informacyjnie adresu zdjęć
/*        if (PhotoAddressInfo == null) PhotoAddressInfo = $"{_serverAddress}/{_photosPath}";*/
    }
/*    public string[] GetPhotosUrl()
    {
        try
        {
            _client.Connect();
            _client.SetWorkingDirectory(_photosPath);
            var urlTab = _client.GetNameListing();
            _client.Disconnect();
            return urlTab;
        }
        catch (Exception)
        {
            return null;
        }
    }*/
    public FtpStatus UploadFile(string fileName)
    {
        _client.Connect();
        _client.RetryAttempts = 3;
        var result = _client.UploadFile(@"..\..\..\Database\pos.db", "/Database/pos.db", FtpRemoteExists.Overwrite, true, FtpVerify.Retry);
        return result;
    }
    public FtpStatus UploadData(StringBuilder data)
    {
        var byteArray = Encoding.GetEncoding(28592).GetBytes(data.ToString());
        _client.Connect();
        _client.UploadDataType = FtpDataType.Binary;
        _client.RetryAttempts = 3;
        var fileName = "";
        var send = _client.Upload(byteArray, "Eryk/" + fileName, FtpRemoteExists.Overwrite, true);
        return send;
    }
    public bool ConnectionStatus()
    {
        try
        {
            _client.Connect();
            _client.Disconnect();
            return true;
        }
        catch (Exception)
        {
            return false;
        }
    }
}
